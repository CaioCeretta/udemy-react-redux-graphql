# robofriends-testing

To run the project: 

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
4. Run tests with `npm test` -- you may have to press "a" to run all tests

HEADS UP! Depending on your version of Jest, you may find that your snapshots aren't created properly (empty). This is a known issue and may require you to do the following: https://stackoverflow.com/questions/54419342/jest-enzyme-shallowwrapper-is-empty-when-creating-snapshot. I have included the code change mentioned in the article (package.json) in this git repo to show you how to do this if you encounter the issue.

*visist https://zerotomastery.io/ for more*

